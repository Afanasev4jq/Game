package com.example.game2;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class StatisticsActivity extends Activity {

    private ListView listView;
    private ArrayAdapter<GameStat> adapter;
    private List<GameStat> gameStats;
    private boolean isSorted = false;
    private List<GameStat> originalGameStats;


    private List<GameStat> getDataFromDatabase() {
        DBHelper dbHelper = new DBHelper(this);
        return new ArrayList<>(dbHelper.getAllGameStats());
    }



    public StatisticsActivity() {
    }
    private void showBestResult() {
        if (!gameStats.isEmpty()) {
            // Sort the game stats in descending order by score
            Collections.sort(gameStats, new Comparator<GameStat>() {
                public int compare(GameStat stat1, GameStat stat2) {
                    return Integer.compare(stat2.getScore(), stat1.getScore());
                }
            });

            List<GameStat> bestStats = new ArrayList<>();
            bestStats.add(gameStats.get(0)); // Add the highest score to the list

            adapter.clear();
            adapter.addAll(bestStats);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.statistics);
        Button back = findViewById(R.id.btn_show_all);
        Button best = findViewById(R.id.the_best);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button stat = findViewById(R.id.btn_statistics);
        listView = findViewById(R.id.list);
        gameStats = getDataFromDatabase();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, gameStats);
        listView.setAdapter(adapter);
        Button sortButton = findViewById(R.id.btn_sort);
        originalGameStats = new ArrayList<>(gameStats);



        /*sortButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isSorted) {

                    Collections.sort(gameStats, new Comparator<GameStat>() {
                        public int compare(GameStat stat1, GameStat stat2) {
                            return Integer.compare(stat2.getScore(), stat1.getScore());
                        }
                    });
                    isSorted = true;
                } else {

                    gameStats = getDataFromDatabase();
                    isSorted = false;
                }

                adapter.notifyDataSetChanged();
            }
        });*/ back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StatisticsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        best.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBestResult();
            }
        });
        stat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Восстановление исходного списка
                gameStats.clear();
                gameStats.addAll(originalGameStats);
                isSorted = false;
                adapter.notifyDataSetChanged();
            }
        });





    }
}